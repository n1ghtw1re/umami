import Page from '@/app/(main)/settings/websites/[websiteId]/page';

export default function ({ params }) {
  return <Page params={params} />;
}
