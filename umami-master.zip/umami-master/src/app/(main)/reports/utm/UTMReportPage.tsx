import UTMReport from './UTMReport';

export default function UTMReportPage() {
  return <UTMReport />;
}
