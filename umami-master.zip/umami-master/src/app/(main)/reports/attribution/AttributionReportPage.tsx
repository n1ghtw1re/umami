'use client';
import AttributionReport from './AttributionReport';

export default function AttributionReportPage() {
  return <AttributionReport />;
}
