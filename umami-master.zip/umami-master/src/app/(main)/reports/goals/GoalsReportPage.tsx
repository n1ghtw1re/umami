'use client';
import GoalReport from './GoalsReport';

export default function GoalReportPage() {
  return <GoalReport />;
}
