'use client';
import ReportTemplates from './ReportTemplates';

export default function ReportCreatePage() {
  return <ReportTemplates />;
}
